1) In order to test the code go to the Submission-1 directory and just run the shell script and it will give you the result based on the tweets already downloaded. This just eliminates the overhead of downloading and processing the data. Use the following command to do so:

sh project.sh

once you go to the Submission-1 then there are further instructions and comments.

2) If in order to do it the long way by downloading the tweets and finance data, labelling the data, and then running the analysis go to the Submission-2 directory and follow instructions given in the directory.               
