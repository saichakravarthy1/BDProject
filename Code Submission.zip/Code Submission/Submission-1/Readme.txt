1) Run the scala code using the shell script. 

 sh project.sh

2) This scala code is hardcoded to a path just to eliminate the overhead of downloading the tweets.

3) If some other file has to be given as input the scala file has to be edited by replacing the path of the file to the path of the desired file. 
