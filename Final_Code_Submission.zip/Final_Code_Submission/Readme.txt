i)The project consists of two directories, Submission-1 and Submission-2.
ii)Submission-1 consists of the experiment we conducted by downloading the tweets from 24th July to 31st July. We downloaded the corresponding finance data from yahoo finance, labelled the data and ran sentiment analysis on it. The entire code is available in the Submission-1 directory. 
 

   1) In order to test the code go to the Submission-1 directory and just run the shell script and it will give you the result based on the tweets already downloaded. This just eliminates the overhead of downloading and processing the data. Use the following command to do so:

              sh project.sh

   once you go to the Submission-1 then there are further instructions and comments.


iii)Submission-2 consists of the code and instructions to download the tweets and yahoo finance data for the past seven days, from the current date and run analysis on it. 
iv) This involves performing all the steps we did and further instructions to run the entire code.

   2) If in order to do it the long way by downloading the tweets and finance data, labelling the data, and then running the analysis go to the Submission-2 directory and follow instructions given in the directory.               


*We used Apple Inc to predict the stocks any company can be used, but for simplicity we stuck to one company. AAPL is the symbol for Apple company in the stock trade.