#!/bin/bash

spark-shell -i categ.scala